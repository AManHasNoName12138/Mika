import json,subprocess,pathlib
root=pathlib.Path('/workspace/Mika');u=root/'.ua';s=pathlib.Path('/workspace/understand-anything-skill/understand-anything-plugin/skills/understand')
batches=json.loads((u/'intermediate/batches.json').read_text())['batches']
for b in batches:
 i=b['batchIndex'];inp=u/f'tmp/input-{i}.json';out=u/f'tmp/extract-{i}.json'
 inp.write_text(json.dumps({'projectRoot':str(root),'batchFiles':b['files'],'batchImportData':b['batchImportData']}))
 p=subprocess.run(['node',str(s/'extract-structure.mjs'),str(inp),str(out)],capture_output=True,text=True)
 (u/f'tmp/extract-{i}.stderr').write_text(p.stderr)
 if p.returncode or not out.is_file():raise RuntimeError(f'Extraction failed {i}: {p.stderr}')
 d=json.loads(out.read_text())
 if d.get('filesUnreadable'):raise RuntimeError(f'Unreadable files {i}')
 print(f'Extracted batch {i}/{len(batches)}',flush=True)
groups=[{'group':i+1,'size':0,'batches':[]} for i in range(5)]
for b in sorted(batches,key=lambda b:sum(f['sizeLines'] for f in b['files']),reverse=True):
 g=min(groups,key=lambda g:g['size']);g['batches'].append(b);g['size']+=sum(f['sizeLines']+50 for f in b['files'])
for g in groups:
 g['batches'].sort(key=lambda b:b['batchIndex']);(u/f'tmp/assignment-{g["group"]}.json').write_text(json.dumps(g))
