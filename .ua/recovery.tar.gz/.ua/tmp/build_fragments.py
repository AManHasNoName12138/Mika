import json, re, math, pathlib, collections, sys, xml.etree.ElementTree as ET

ROOT = pathlib.Path('/workspace/Mika')
UA = ROOT / '.ua'
ROLE = {
 'agent':'模型与工具调度', 'action':'动作执行与核查', 'tool':'工具注册和分发',
 'run':'运行契约与交互信号', 'task':'Android任务生命周期和调度',
 'uistate':'屏幕观察与交互状态', 'phone':'手机控制', 'web':'网页浏览与操作',
 'sandbox':'Linux沙箱与文件处理', 'model':'模型协议与请求', 'context':'模型上下文',
 'memory':'个人记忆与学习', 'knowledge':'应用知识和技能', 'prompt':'提示词装配',
 'ui':'Compose用户界面', 'settings':'配置与账户管理', 'trace':'运行追踪',
 'record':'运行记录', 'trigger':'定时与条件触发', 'mcp':'MCP连接', 'remote':'远程任务',
 'replay':'经验回放', 'voice':'语音输入', 'wechat':'微信渠道', 'capsule':'悬浮胶囊交互',
 'chat':'对话持久化', 'assembly':'能力装配', 'gate':'执行确认', 'guard':'运行守卫',
 'workspace':'任务工作区', 'device':'设备访问', 'relay':'远程中继', 'eval':'行为评测',
 'i18n':'界面多语言', 'selfcheck':'设备兼容性检查', 'takeover':'用户接管',
}
WEIGHTS={'contains':1.,'exports':.8,'imports':.7,'calls':.8,'tested_by':.5,'documents':.5,'configures':.6,'depends_on':.6,'deploys':.7,'triggers':.6,'related':.5}

def short(text, size=280):
    text=re.sub(r'\s+',' ',text).strip(' *\n\t')
    return text if len(text)<=size else text[:size].rstrip('，,；; ')+'…'

def cn(text): return bool(re.search(r'[\u4e00-\u9fff]',text))

def role(path):
    parts=path.split('/')
    return '、'.join(dict.fromkeys(ROLE[p] for p in parts if p in ROLE)) or '项目构建与公共支持'

def category_type(f):
    p=f['path'];c=f['fileCategory']
    if p.endswith('.gradle.kts'):return 'config'
    if c=='docs' or pathlib.Path(p).name in ['LICENSE','NOTICE']:return 'document'
    if c=='config':return 'config'
    if c=='infra':return 'pipeline' if '/workflows/' in p else 'service'
    if c=='data':return 'schema'
    return 'file'

def kdoc(text,start):
    prefix='\n'.join(text.splitlines()[:max(0,start-1)])
    matches=list(re.finditer(r'/\*\*([\s\S]*?)\*/',prefix))
    if matches:
        m=matches[-1]; tail=prefix[m.end():]
        if len(tail.splitlines())<9 and not re.search(r'\b(?:fun|class|object|interface|val|var)\b|[{};]',tail):
            doc=re.sub(r'(?m)^\s*\* ?', '',m.group(1))
            doc=re.split(r'\s@(?:param|return|throws|see)\b',doc)[0]
            if cn(doc):return short(doc)
    return None

def file_summary(f,r,text):
    p=f['path'];typ=category_type(f);area=role(p);name=pathlib.Path(p).name
    funcs=[z['name'] for z in r.get('functions',[])]; classes=[z['name'] for z in r.get('classes',[])]
    test='/test/' in p or '/androidTest/' in p or name.endswith('_test.go') or name.startswith('test_')
    if p.endswith('.xml'):
        try:
            root=ET.fromstring(text);children=list(root)
            if root.tag=='resources':
                counts=collections.Counter(x.tag for x in children);keys=[x.get('name') for x in children if x.get('name')]
                locale=next((s for s in p.split('/') if s.startswith('values')), 'values')
                return f'提供 Android {locale} 资源，包含'+ '、'.join(f'{v}个{k}' for k,v in counts.items())+'；资源键包括 '+ '、'.join(keys[:5])+'。'
            return f'声明 Android {root.tag} 配置，包含 '+ '、'.join(dict.fromkeys(x.tag for x in children))+' 等元素，供应用组件与系统集成使用。'
        except ET.ParseError: return '保存 XML 格式的配置或测试输入；内容从 '+short(text,150)+' 开始。'
    if p.endswith('.json'):
        try:
            data=json.loads(text)
            if isinstance(data,dict):
                desc=next((data[k] for k in ['description','goal','name','title','instruction'] if isinstance(data.get(k),str) and data[k]),'')
                return short(('定义评测任务与预期行为。' if p.startswith('eval/') else '保存结构化配置或测试数据。')+(f'主题：{desc}。' if desc else '')+'字段包括 '+ '、'.join(list(data)[:10])+'。')
            return f'保存 JSON 数组数据，共 {len(data)} 项，作为配置或测试输入。'
        except (ValueError,TypeError): return '保存用于解析器或契约测试的 JSON 输入样例。'
    if typ=='document':
        heads=re.findall(r'^#{1,4}\s+(.+)',text,re.M)
        front=re.search(r'^description:\s*[>|]?\s*(.+)$',text,re.M)
        if front and cn(front.group(1)):return short(front.group(1))
        if heads:return '说明 '+ '；'.join(short(x,65) for x in heads[:5])+'。'
        return '记录提示词、输出快照或许可说明。内容起始为：'+short(text,220)
    if test:
        return f'回归验证{area}；测试场景包括 '+ '、'.join(funcs[:7] or classes[:4] or [name])+'。'
    if typ in ['service','pipeline']:
        if 'Dockerfile' in name:return '定义容器构建与运行流程，阶段包括 '+ '、'.join(re.findall(r'(?im)^FROM\s+(.+)',text))+'。'
        return '配置持续集成或部署流程，内容涉及 '+short(text,210)+'。'
    if typ=='config':
        return f'配置{area}，声明 '+short(text,210)+'。'
    definitions=sorted(r.get('classes',[])+r.get('functions',[]),key=lambda z:z.get('startLine',0))
    for d in definitions[:4]:
        doc=kdoc(text,d.get('startLine',1))
        if doc:return doc
    comments=re.findall(r'(?m)^\s*//\s*(.+)',text)
    useful=[x for x in comments if cn(x) and len(x)>15]
    if useful:return short(useful[0])
    parts=[]
    if classes:parts.append('定义 '+ '、'.join(classes[:5])+' 类型')
    if funcs:parts.append('提供 '+ '、'.join(funcs[:7])+' 操作')
    if parts:return f'支撑{area}，'+'，'.join(parts)+'。'
    if p.endswith('.html'):return '提供网页交互或浏览器测试页面，标题/元素包括 '+short('、'.join(re.findall(r'<(?:title|h[1-3]|button)[^>]*>(.*?)</',text,re.S)[:6]),200)+'。'
    if p.endswith('.css'):return '定义网页与测试页面的布局、颜色和交互状态样式；选择器包括 '+ '、'.join(re.findall(r'([^{}]+)\{',text)[:6])+'。'
    return '保存'+area+'使用的文本定义，内容起始为：'+short(text,180)

def build(batch):
    idx=batch['batchIndex']; extract=json.loads((UA/f'tmp/extract-{idx}.json').read_text()); bypath={r['path']:r for r in extract['results']}
    nodes=[];edges=[];keys=set();sources={};meta=[]
    def edge(a,b,t):
        if a!=b and (a,b,t) not in keys:
            edges.append({'source':a,'target':b,'type':t,'direction':'forward','weight':WEIGHTS.get(t,.5)});keys.add((a,b,t))
    for f in batch['files']:
        p=f['path'];text=(ROOT/p).read_text();r=bypath.get(p,{})
        typ=category_type(f);fid=f'{typ}:{p}'; summary=file_summary(f,r,text);test='/test/' in p or '/androidTest/' in p or p.endswith('_test.go') or pathlib.Path(p).name.startswith('test_')
        tags=[f['language'],'测试' if test else {'document':'文档','config':'配置','pipeline':'持续集成','service':'部署'}.get(typ,'实现'),role(p)]
        nonempty=sum(bool(l.strip()) for l in text.splitlines());complexity='simple' if nonempty<50 else 'moderate' if nonempty<=200 else 'complex'
        nodes.append(dict(id=fid,type=typ,name=pathlib.Path(p).name,filePath=p,summary=summary,tags=tags,complexity=complexity))
        meta.append(dict(path=p,id=fid,summary=summary,category=f['fileCategory'],language=f['language'],officialSkipped=p in extract.get('filesSkipped',[])))
        for target in batch['batchImportData'].get(p,[]):edge(fid,'file:'+target,'imports')
        classes=[c for c in r.get('classes',[]) if c['name'] not in ['return','when','else','if','companion']]
        funcs=r.get('functions',[]);exports={x['name'] for x in r.get('exports',[])};symbolmap=collections.defaultdict(list);symbols=[]
        def owner_for(z):
            parents=[c for c in classes if c is not z and c['startLine']<z['startLine'] and z['endLine']<=c['endLine']]
            return sorted(parents,key=lambda c:c['startLine'])
        for kind,defs in [('class',classes),('function',funcs)]:
            for z in defs:
                st,en=z['startLine'],z['endLine']; length=en-st+1
                if not (1<=st<=en<=f['sizeLines']):continue
                if kind=='function' and (length<=1 or (length<10 and z['name'] not in exports)):continue
                if kind=='class' and length<20 and len(z.get('methods',[]))<2 and z['name'] not in exports:continue
                owner=owner_for(z);q='.'.join([c['name'] for c in owner]+[z['name']]);nid=f'{kind}:{p}:{q}'
                if any(n['id']==nid for n in nodes):nid+=f'@{st}'
                doc=kdoc(text,st)
                if not doc:
                    if kind=='class':doc=f'定义 {q}，用于{role(p)}。'+('操作包括 '+ '、'.join(z.get('methods',[])[:6])+'。' if z.get('methods') else '字段包括 '+ '、'.join(z.get('properties',[])[:6])+'。' if z.get('properties') else '')
                    elif test:doc=f'验证 {z["name"]} 场景，守住{role(p)}的行为约定。'
                    else:
                        calls=list(dict.fromkeys(x['callee'] for x in r.get('callGraph',[]) if x.get('caller')==z['name']))[:5]
                        doc=f'执行 {q}，参与{role(p)}。'+('调用 '+ '、'.join(calls)+' 完成处理。' if calls else '参数包括 '+ '、'.join(str(a) for a in z.get('params',[])[:5])+'。' if z.get('params') else '')
                node=dict(id=nid,type=kind,name=q,filePath=p,lineRange=[st,en],summary=short(doc),tags=[f['language'],'测试' if test else '类型' if kind=='class' else '函数',role(p)],complexity='simple' if length<50 else 'moderate' if length<=200 else 'complex')
                nodes.append(node);symbols.append(node);symbolmap[z['name']].append(nid);edge(fid,nid,'contains')
                if z['name'] in exports:edge(fid,nid,'exports')
        for node in symbols:
            owners=[x for x in symbols if x['type']=='class' and x['lineRange'][0]<node['lineRange'][0] and node['lineRange'][1]<=x['lineRange'][1]]
            if owners:edge(min(owners,key=lambda x:x['lineRange'][1]-x['lineRange'][0])['id'],node['id'],'contains')
        for call in r.get('callGraph',[]):
            a=symbolmap.get(call.get('caller'),[]);b=symbolmap.get(call.get('callee'),[])
            if len(a)==len(b)==1:edge(a[0],b[0],'calls')
        sources[p]=text
    overrides_path=UA/f'tmp/overrides-{idx}.json'
    if overrides_path.exists():
        over=json.loads(overrides_path.read_text())
        for n in nodes:
            if n['id'] in over:n.update(over[n['id']])
    parts=max(1,math.ceil(max(len(nodes)/60,len(edges)/120))); paths=sorted(sources);size=max(1,math.ceil(len(paths)/parts))
    outputs=[]
    for k,start in enumerate(range(0,len(paths),size),1):
        wanted=set(paths[start:start+size]);ns=[n for n in nodes if n.get('filePath') in wanted];ids={n['id'] for n in ns};es=[e for e in edges if e['source'] in ids]
        out=UA/f'intermediate/batch-{idx}-part-{k}.json';out.write_text(json.dumps({'nodes':ns,'edges':es},ensure_ascii=False));outputs.append(out.name)
    (UA/f'tmp/file-review-{idx}.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
    return {'batchIndex':idx,'files':len(batch['files']),'nodes':len(nodes),'edges':len(edges),'parts':outputs,'unreadable':extract.get('filesUnreadable',[]),'officialSkipped':extract.get('filesSkipped',[])}

if __name__=='__main__':
    batches=json.loads((UA/'intermediate/batches.json').read_text())['batches'];wanted=set(map(int,sys.argv[1:])) if len(sys.argv)>1 else None
    reports=[]
    for b in batches:
        if wanted is not None and b['batchIndex'] not in wanted:continue
        reports.append(build(b));print(f'Batch {b["batchIndex"]}: {len(b["files"])} files',flush=True)
    (UA/'tmp/bootstrap-report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))
